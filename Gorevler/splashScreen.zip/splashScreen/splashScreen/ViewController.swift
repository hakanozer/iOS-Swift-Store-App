//
//  ViewController.swift
//  splashScreen
//
//  Created by Işıl Koç Şahin on 15.01.2017.
//  Copyright © 2017 barishan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var dizi:[UIImage] = []

    @IBOutlet weak var resim: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        for item in 1...45 {
            dizi.append(UIImage(named:"\(item)")!)
        }
        self.resim.animationImages = dizi
        self.resim.animationDuration = TimeInterval(1)
        self.resim.startAnimating()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { (Timer) in
            self.performSegue(withIdentifier: "anasayfa", sender: nil)
            
            
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

